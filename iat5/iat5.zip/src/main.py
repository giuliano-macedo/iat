import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm

def sig(z,deriv=False):
	if deriv:
		temp=sig(z)
		return temp*(1-temp)
	return 1/(1+np.exp(-z))

def relu(x,deriv=False):
	if deriv:
		return f2(x)
	return f1(x)
f1=np.vectorize(lambda x:0 if x<0 else x)
f2=np.vectorize(lambda x:0 if x<0 else 1)

x=np.array([
	[0,0,1,1],
	[0,1,0,1]
])
m=4
y=np.array([[0,1,1,0]])

np.random.seed(42)

g=sig
# g=relu
a0=x

b=3

p=0.1

w1=np.random.rand(b,2)*p
b1=np.random.rand(b,1)*p

w2=np.random.rand(1,b)*p
b2=np.random.rand(1,1)*p


alpha=5

js=[]
accrs=[]

for i in tqdm(range(1000)):
	z1=(w1.dot(a0))+b1
	a1=g(z1)

	z2=(w2.dot(a1))+b2
	a2=g(z2)

	dz2=a2-y
	dw2=(1/m)*(dz2.dot(a1.T))
	db2=(1/m)*np.sum(dz2,axis=1,keepdims=True)

	# dz1=(w2.T.dot(dz2))*g(z1,True)
	dz1=(w2.T.dot(dz2))*(a1*(1-a1))
	dw1=(1/m)*(dz1.dot(x.T))
	db1=(1/m)*np.sum(dz1,axis=1,keepdims=True)


	w2-= alpha*dw2
	b2-= alpha*db2
	
	w1-= alpha*dw1
	b1-= alpha*db1

	j=1/m * np.sum(-y*np.log(a2) - (1-y)*np.log(1-a2))
	accr=np.sum(y==(a2>=0.5))/m

	js.append(j.copy())
	accrs.append(accr.copy())

print(a2)

plt.plot(js)
plt.xlabel("Épocas")
plt.ylabel("$J$")

plt.figure()

plt.plot(np.asarray(accrs)*100)
plt.xlabel("Épocas")
plt.ylabel("acúracia (%)")
plt.show()